import 'package:flutter/material.dart';
import 'package:flutter_html/flutter_html.dart'; // ✅ Import flutter_html

class JobDetailScreen extends StatelessWidget {
  final String title;
  final String company;
  final String location;
  final String description;

  const JobDetailScreen({
    super.key,
    required this.title,
    required this.company,
    required this.location,
    required this.description,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(title)),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                company,
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.blue),
              ),
              SizedBox(height: 8),
              Text(
                location,
                style: TextStyle(fontSize: 16, fontStyle: FontStyle.italic, color: Colors.grey[700]),
              ),
              SizedBox(height: 16),
              Text(
                "Job Description",
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              SizedBox(height: 8),
              Html(
                data: description, // ✅ Render HTML properly
                style: {
                  "body": Style(
                    fontSize: FontSize(16.0),
                    color: Colors.black87,
                  ),
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}
