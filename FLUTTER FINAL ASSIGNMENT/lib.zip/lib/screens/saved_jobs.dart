import 'package:flutter/material.dart';
import '../database/db_helper.dart';

class SavedJobsScreen extends StatefulWidget {
  @override
  _SavedJobsScreenState createState() => _SavedJobsScreenState();
}

class _SavedJobsScreenState extends State<SavedJobsScreen> {
  List<Map<String, dynamic>> savedJobs = [];

  @override
  void initState() {
    super.initState();
    loadSavedJobs();
  }

  Future<void> loadSavedJobs() async {
    final dbHelper = DatabaseHelper();
    final jobs = await dbHelper.getSavedJobs();
    setState(() {
      savedJobs = jobs;
    });
  }

  void deleteJob(String title) async {
    final dbHelper = DatabaseHelper();
    await dbHelper.deleteJob(title);
    loadSavedJobs(); // Refresh the list
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Saved Jobs")),
      body: savedJobs.isEmpty
          ? Center(child: Text("No saved jobs yet."))
          : ListView.builder(
              itemCount: savedJobs.length,
              itemBuilder: (context, index) {
                final job = savedJobs[index];
                return Card(
                  margin: EdgeInsets.all(8),
                  child: ListTile(
                    title: Text(job["title"], style: TextStyle(fontWeight: FontWeight.bold)),
                    subtitle: Text("${job["company"]} - ${job["location"]}"),
                    trailing: IconButton(
                      icon: Icon(Icons.delete, color: Colors.red),
                      onPressed: () => deleteJob(job["title"]),
                    ),
                  ),
                );
              },
            ),
    );
  }
}
