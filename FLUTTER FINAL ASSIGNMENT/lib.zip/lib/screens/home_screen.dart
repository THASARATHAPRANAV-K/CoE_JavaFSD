import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../utils/locale_provider.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';

class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final localeProvider = Provider.of<LocaleProvider>(context);

    return Scaffold(
      appBar: AppBar(
        title: Text(AppLocalizations.of(context)!.welcome),
        actions: [
          PopupMenuButton<Locale>(
            onSelected: (Locale locale) {
              localeProvider.setLocale(locale);
            },
            itemBuilder: (BuildContext context) => <PopupMenuEntry<Locale>>[
              PopupMenuItem<Locale>(
                value: Locale('en', 'US'),
                child: Text("English"),
              ),
              PopupMenuItem<Locale>(
                value: Locale('es', 'ES'),
                child: Text("Español"),
              ),
              PopupMenuItem<Locale>(
                value: Locale('ta', 'IN'),
                child: Text("தமிழ்"),
              ),
            ],
          ),
        ],
      ),
      body: Center(
        child: Text(AppLocalizations.of(context)!.welcome),
      ),
    );
  }
}
