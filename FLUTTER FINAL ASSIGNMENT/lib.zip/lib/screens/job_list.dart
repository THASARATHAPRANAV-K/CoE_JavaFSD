import 'package:flutter/material.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:firebase_auth/firebase_auth.dart';
import '../database/db_helper.dart';
import 'job_detail.dart';
import '../widgets/job_card.dart';
import 'saved_jobs.dart';
import 'profile_screen.dart';
import 'login_screen.dart';

class JobList extends StatefulWidget {
  @override
  _JobListState createState() => _JobListState();
}

class _JobListState extends State<JobList> {
  List<dynamic> jobs = [];
  List<dynamic> filteredJobs = [];
  bool isLoading = true;
  String searchQuery = '';
  String selectedCategory = 'All';
  final DatabaseHelper dbHelper = DatabaseHelper();
  final FirebaseAuth _auth = FirebaseAuth.instance;
  User? user;

  @override
  void initState() {
    super.initState();
    fetchJobs();
    getUser();
  }

  void getUser() {
    setState(() {
      user = _auth.currentUser;
    });
  }

  Future<void> fetchJobs() async {
    const String apiUrl = "https://remotive.io/api/remote-jobs";
    try {
      final response = await http.get(Uri.parse(apiUrl));
      if (response.statusCode == 200) {
        final data = json.decode(response.body);

        if (data.containsKey("jobs") && data["jobs"] != null) {
          setState(() {
            jobs = data["jobs"];
            filteredJobs = jobs;
            isLoading = false;
          });
        } else {
          setState(() {
            jobs = [];
            filteredJobs = [];
            isLoading = false;
          });
        }
      } else {
        throw Exception("Failed to load jobs");
      }
    } catch (e) {
      setState(() {
        isLoading = false;
      });
      print("Error fetching jobs: $e");
    }
  }

  Future<void> saveJob(Map<String, dynamic> job) async {
    await dbHelper.saveJob({
      "title": job["title"] ?? "Unknown",
      "company": job["company"] ?? job["company_name"] ?? "Unknown",
      "location": job["candidate_required_location"] ?? "Remote",
      "description": job["description"] ?? "No description available.",
    });

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text("${job["title"]} saved!")),
    );
  }

  void filterJobs() {
    setState(() {
      filteredJobs = jobs.where((job) {
        bool matchesSearch = job["title"]
                .toLowerCase()
                .contains(searchQuery.toLowerCase()) ||
            (job["company"] ?? job["company_name"] ?? "")
                .toLowerCase()
                .contains(searchQuery.toLowerCase());

        bool matchesCategory =
            selectedCategory == 'All' || job["category"] == selectedCategory;

        return matchesSearch && matchesCategory;
      }).toList();
    });
  }

  void logout() async {
    await _auth.signOut();
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (context) => LoginScreen()),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Job Listings"),
        actions: [
          IconButton(
            icon: Icon(Icons.account_circle, size: 28),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => ProfileScreen(user: user)),
              );
            },
          ),
          IconButton(
            icon: Icon(Icons.logout, size: 28),
            onPressed: logout,
          ),
          IconButton(
            icon: Icon(Icons.bookmark),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => SavedJobsScreen(),
                ),
              );
            },
          ),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(10.0),
            child: TextField(
              decoration: InputDecoration(
                hintText: "Search by job title or company...",
                prefixIcon: Icon(Icons.search),
                border:
                    OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
              ),
              onChanged: (value) {
                setState(() {
                  searchQuery = value;
                  filterJobs();
                });
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 10),
            child: DropdownButtonFormField<String>(
              value: selectedCategory,
              decoration: InputDecoration(
                border:
                    OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
              ),
              items: [
                "All",
                "Software Development",
                "Marketing",
                "Design",
                "Customer Support"
              ]
                  .map((category) =>
                      DropdownMenuItem(value: category, child: Text(category)))
                  .toList(),
              onChanged: (value) {
                setState(() {
                  selectedCategory = value!;
                  filterJobs();
                });
              },
            ),
          ),
          Expanded(
            child: isLoading
                ? Center(child: CircularProgressIndicator())
                : filteredJobs.isEmpty
                    ? Center(child: Text("No jobs found"))
                    : ListView.builder(
                        itemCount: filteredJobs.length,
                        itemBuilder: (context, index) {
                          final job = filteredJobs[index];
                          return JobCard(
                            title: job["title"] ?? "Unknown",
                            company: job["company"] ?? job["company_name"] ?? "Unknown",
                            location:
                                job["candidate_required_location"] ?? "Remote",
                            description:
                                job["description"] ?? "No description available.",
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => JobDetailScreen(
                                    title: job["title"] ?? "Unknown",
                                    company: job["company"] ?? job["company_name"] ?? "Unknown",
                                    location: job["candidate_required_location"] ?? "Remote",
                                    description: job["description"] ?? "No description available.",
                                  ),
                                ),
                              );
                            },
                            onSave: () {
                              saveJob(job);
                            },
                          );
                        },
                      ),
          ),
        ],
      ),
    );
  }
}
