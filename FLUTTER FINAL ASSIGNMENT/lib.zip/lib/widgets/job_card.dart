import 'package:flutter/material.dart';
import '../database/db_helper.dart';

class JobCard extends StatefulWidget {
  final String title;
  final String company;
  final String location;
  final String description;
  final VoidCallback onTap; // Navigate to Job Details
  final VoidCallback onSave; // ✅ Added onSave parameter

  const JobCard({
    super.key,
    required this.title,
    required this.company,
    required this.location,
    required this.description,
    required this.onTap,
    required this.onSave, // ✅ Marked as required
  });

  @override
  _JobCardState createState() => _JobCardState();
}

class _JobCardState extends State<JobCard> {
  bool _isTapped = false;
  bool _isSaved = false; // Track if job is saved

  void saveJob() async {
    final dbHelper = DatabaseHelper();
    await dbHelper.saveJob({
      'title': widget.title,
      'company': widget.company,
      'location': widget.location,
      'description': widget.description,
    });

    setState(() {
      _isSaved = true;
    });

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text("${widget.title} saved!")),
    );
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => setState(() => _isTapped = true),
      onTapUp: (_) => setState(() => _isTapped = false),
      onTapCancel: () => setState(() => _isTapped = false),
      onTap: widget.onTap,
      onLongPress: () {
        _showOptionsMenu(context);
      },
      child: Dismissible(
        key: Key(widget.title), // Unique key for swipe action
        direction: DismissDirection.startToEnd, // Swipe right to save
        background: Container(
          color: Colors.green,
          alignment: Alignment.centerLeft,
          padding: EdgeInsets.symmetric(horizontal: 20),
          child: Icon(Icons.bookmark, color: Colors.white, size: 30),
        ),
        onDismissed: (direction) {
          saveJob();
        },
        child: AnimatedScale(
          scale: _isTapped ? 0.97 : 1.0,
          duration: Duration(milliseconds: 150),
          child: Card(
            margin: EdgeInsets.symmetric(horizontal: 10, vertical: 8),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
            elevation: 6,
            child: ListTile(
              contentPadding: EdgeInsets.all(12),
              leading: CircleAvatar(
                backgroundColor: Colors.blue.shade100,
                child: Icon(Icons.work, color: Colors.blue.shade700),
              ),
              title: Text(
                widget.title,
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
              ),
              subtitle: Text(
                '${widget.company} • ${widget.location}',
                style: TextStyle(color: Colors.grey[700]),
              ),
              trailing: IconButton(
                icon: Icon(
                  _isSaved ? Icons.favorite : Icons.favorite_border,
                  color: _isSaved ? Colors.red : Colors.grey,
                ),
                onPressed: widget.onSave, // ✅ FIXED: Use widget.onSave
              ),
            ),
          ),
        ),
      ),
    );
  }

  void _showOptionsMenu(BuildContext context) {
    showModalBottomSheet(
      context: context,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (context) {
        return Wrap(
          children: [
            ListTile(
              leading: Icon(Icons.visibility),
              title: Text('View Details'),
              onTap: () {
                Navigator.pop(context);
                widget.onTap();
              },
            ),
            ListTile(
              leading: Icon(Icons.share),
              title: Text('Share'),
              onTap: () {
                Navigator.pop(context);
                _shareJob();
              },
            ),
          ],
        );
      },
    );
  }

  void _shareJob() {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text("Sharing ${widget.title}...")),
    );
  }
}
