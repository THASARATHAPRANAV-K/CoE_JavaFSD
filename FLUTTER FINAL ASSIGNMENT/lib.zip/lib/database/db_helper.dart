import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';

class DatabaseHelper {
  static final DatabaseHelper _instance = DatabaseHelper._internal();
  static Database? _database;

  factory DatabaseHelper() {
    return _instance;
  }

  DatabaseHelper._internal();

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDatabase();
    return _database!;
  }

  Future<Database> _initDatabase() async {
    try {
      final path = join(await getDatabasesPath(), 'jobs.db');
      return await openDatabase(
        path,
        version: 1,
        onCreate: (db, version) async {
          await db.execute('''
            CREATE TABLE favorites (
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              title TEXT UNIQUE, 
              company TEXT,
              location TEXT,
              description TEXT
            )
          ''');
        },
      );
    } catch (e) {
      print("Database initialization error: $e");
      throw Exception("Database initialization failed");
    }
  }

  Future<int> saveJob(Map<String, dynamic> job) async {
    try {
      final db = await database;
      return await db.insert('favorites', job, conflictAlgorithm: ConflictAlgorithm.ignore);
    } catch (e) {
      print("Error saving job: $e");
      return -1; // Return -1 to indicate failure
    }
  }

  Future<List<Map<String, dynamic>>> getSavedJobs() async {
    try {
      final db = await database;
      return await db.query('favorites');
    } catch (e) {
      print("Error fetching saved jobs: $e");
      return [];
    }
  }

  Future<int> deleteJob(String title) async {
    try {
      final db = await database;
      return await db.delete('favorites', where: 'title = ?', whereArgs: [title]);
    } catch (e) {
      print("Error deleting job: $e");
      return -1;
    }
  }

  Future<void> closeDatabase() async {
    final db = await _database;
    if (db != null) {
      await db.close();
      _database = null;
    }
  }
}
