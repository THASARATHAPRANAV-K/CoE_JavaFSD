export interface Project {
  id: number;
  title: string;
  skills: string[];
  budget: number;
}
