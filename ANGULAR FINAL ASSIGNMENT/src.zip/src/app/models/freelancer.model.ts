export interface Freelancer {
    id: number;
    name: string;
    skills: string[];
    experience: number;
    rating: number;
  }
  