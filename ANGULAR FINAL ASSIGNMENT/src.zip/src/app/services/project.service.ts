import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { Project } from '../models/project.model';

@Injectable({
  providedIn: 'root'
})
export class ProjectService {
  private projects: Project[] = [
    { id: 1, title: 'E-Commerce Website', skills: ['HTML', 'CSS', 'React'], budget: 75000 },
    { id: 2, title: 'Mobile App Development', skills: ['Flutter', 'Dart'], budget: 120000 }
  ];

  getProjects(): Observable<Project[]> {
    return of(this.projects);
  }
}
