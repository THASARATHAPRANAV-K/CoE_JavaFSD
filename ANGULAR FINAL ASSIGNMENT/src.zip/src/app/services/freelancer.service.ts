import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { Freelancer } from '../models/freelancer.model';

@Injectable({
  providedIn: 'root'
})
export class FreelancerService {
  private freelancers: Freelancer[] = [
    { id: 1, name: 'John Doe', skills: ['React', 'Node.js'], experience: 5, rating: 4.8 },
    { id: 2, name: 'Alice Smith', skills: ['Angular', 'TypeScript'], experience: 7, rating: 4.9 }
  ];

  getFreelancers(): Observable<Freelancer[]> {
    return of(this.freelancers);
  }
}
