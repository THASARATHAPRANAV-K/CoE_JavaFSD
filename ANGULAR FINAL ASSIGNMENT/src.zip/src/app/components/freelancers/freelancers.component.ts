import { Component } from '@angular/core';

@Component({
  selector: 'app-freelancers',
  standalone: true,
  imports: [],
  templateUrl: './freelancers.component.html',
  styleUrls: ['./freelancers.component.css'] // ✅ Fixed typo (plural)
})
export class FreelancersComponent {}
