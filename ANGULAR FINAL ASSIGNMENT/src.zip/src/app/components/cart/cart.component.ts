// cart.component.ts

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {
  cartItems: any[] = [];

  ngOnInit() {
    this.cartItems = this.getCartItemsFromLocalStorage();
  }

  getCartItemsFromLocalStorage(): any[] {
    const cartData = localStorage.getItem('cart');
    if (cartData) {
      return JSON.parse(cartData);
    }
    return [];
  }
}