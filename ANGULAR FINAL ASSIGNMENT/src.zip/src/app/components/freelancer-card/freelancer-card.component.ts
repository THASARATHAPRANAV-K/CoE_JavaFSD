// freelancers.component.ts

import { Component } from '@angular/core';

@Component({
  selector: 'app-freelancers',
  templateUrl: './freelancers.component.html',
  styleUrls: ['./freelancers.component.css']
})
export class FreelancersComponent {
  freelancers = [
    { name: 'Alice Johnson', skills: 'Web Development, JavaScript, Angular', orderAmount: 1000 },
    { name: 'David Smith', skills: 'Graphic Design, UI/UX, Adobe Photoshop', orderAmount: 1500 },
    { name: 'Emily Davis', skills: 'Content Writing, SEO, Blogging', orderAmount: 1750 },
    { name: 'Michael Brown', skills: 'Mobile App Development, Flutter, Kotlin', orderAmount: 1600 },
    { name: 'Sophia Wilson', skills: 'Data Science, Machine Learning, Python', orderAmount: 1800 },
    { name: 'James Anderson', skills: 'Photography, Videography, Editing', orderAmount: 1200 },
    { name: 'Olivia Martinez', skills: 'Digital Marketing, SEO, Google Ads', orderAmount: 2200 },
    { name: 'Daniel Lee', skills: 'Backend Development, Node.js, Express', orderAmount: 1900 },
    { name: 'Emma White', skills: 'Illustration, 3D Animation, Motion Graphics', orderAmount: 2100 },
    { name: 'Liam Harris', skills: 'AI Development, Deep Learning, TensorFlow', orderAmount: 2000 }
  ];
}