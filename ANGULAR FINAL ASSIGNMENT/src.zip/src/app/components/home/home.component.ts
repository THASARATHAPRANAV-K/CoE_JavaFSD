// home.component.ts

import { Component } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent {
  freelancers = [
    { name: 'Alice Johnson', skills: 'Web Development, Database', profileUrl: '/freelancer/alice' },
    { name: 'David Smith', skills: 'Graphic Design, UI/UX, Adobe Suite', profileUrl: '/freelancer/david' },
    { name: 'Emily Davis', skills: 'Content Writing, SEO, Blogging', profileUrl: '/freelancer/emily' }
  ];
}