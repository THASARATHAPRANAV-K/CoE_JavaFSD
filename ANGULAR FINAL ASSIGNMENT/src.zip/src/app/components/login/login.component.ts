// login.component.ts

import { Component } from '@angular/core';
import { UserService } from '../services/user.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  username = '';
  password = '';
  errorMessage = ''; // For displaying error messages

  constructor(private userService: UserService, private router: Router) {}

  login() {
    this.userService.login(this.username, this.password).subscribe(
      (response: any) => {
        // Successful login
        this.errorMessage = ''; // Clear any previous error
        this.router.navigate(['/profile']); // Redirect to profile page
      },
      (error) => {
        // Login failed
        this.errorMessage = 'Invalid username or password.';
      }
    );
  }
}