// projects.component.ts

import { Component } from '@angular/core';

@Component({
  selector: 'app-projects',
  templateUrl: './projects.component.html',
  styleUrls: ['./projects.component.css']
})
export class ProjectsComponent {
  projects = [
    {
      title: 'E-Commerce Website Development',
      skills: 'HTML, CSS, JavaScript, React',
      budget: 15000,
      cartCount: 0
    },
    {
      title: 'Mobile App for Online Learning',
      skills: 'Flutter, Kotlin, Firebase',
      budget: 160000,
      cartCount: 0
    },
    {
      title: 'AI-Based Resume Screening Tool',
      skills: 'Machine Learning, Python, NLP',
      budget: 120000,
      cartCount: 0
    },
    {
      title: 'Blockchain-Based Voting System',
      skills: 'Blockchain, Solidity, Smart Contracts',
      budget: 115000,
      cartCount: 0
    }
  ];

  addToCart(project: any) {
    project.cartCount++;
  }
}