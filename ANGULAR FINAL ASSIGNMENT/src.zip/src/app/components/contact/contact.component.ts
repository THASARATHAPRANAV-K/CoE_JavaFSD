// contact.component.ts

import { Component } from '@angular/core';

@Component({
  selector: 'app-contact',
  templateUrl: './contact.component.html',
  styleUrls: ['./contact.component.css']
})
export class ContactComponent {
  contactInfo = {
    address: '123 Freelancer Hub Street, Tech City, India',
    email: 'support@freelancerhub.com',
    phone: '+91 98765 43210'
  };

  message = {
    name: '',
    email: '',
    text: ''
  };

  sendMessage() {
    console.log('Sending message:', this.message);
    // You'd typically send this data to a backend API here
  }
}