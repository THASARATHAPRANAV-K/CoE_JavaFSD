// about.component.ts

import { Component } from '@angular/core';

@Component({
  selector: 'app-about',
  templateUrl: './about.component.html',
  styleUrls: ['./about.component.css']
})
export class AboutComponent {
  title = 'Welcome to Freelancer Hub';
  mission = 'Our mission is to build a thriving freelance ecosystem where businesses can find expert talent, and freelancers can access the best opportunities worldwide.';
  whyChoose = [
    'Global network of top freelancers and businesses',
    'Secure payments and transparent transactions',
    'Wide range of projects across multiple industries',
    'Career growth and networking opportunities'
  ];
  joinUs = "Whether you're a freelancer seeking projects or a business looking for skilled professionals, Freelancer Hub is the perfect place for you. Start your journey today!";
}